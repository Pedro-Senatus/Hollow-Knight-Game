// --- Chaves BASE do LocalStorage ---
const BASE_KEYS = {
    PROFILE: 'desconecte_se_profile',
    POSTS: 'desconecte_se_posts',
    METAS: 'desconecte_se_metas',
    CURRENT_USER_EMAIL_KEY: 'current_user_email'
};

// --- Configurações do Dashboard ---
const CHART_CONFIG = {
    TOTAL_HOURS_DAY: 24,
    DEFAULT_OFFLINE_GOAL: 2,
    HOURS_PER_ACTIVITY: 1
};

// --- Estado Global ---
let currentUserEmail = '';
let currentProfilePhotoBase64 = '';
let currentPostImageBase64 = '';
let currentPosts = [];

// Declara 'elements' fora, mas inicializa dentro de initDashboard
let elements = {}; 


// =================================================================
//          1. FUNÇÕES DE UTILIDADE (loadFromStorage, etc.)
// =================================================================

function loadFromStorage(baseKey, defaultValue) {
    const key = `${baseKey}_${currentUserEmail}`;
    const data = localStorage.getItem(key);
    try {
        return data ? JSON.parse(data) : defaultValue;
    } catch (e) {
        console.error(`Erro ao parsear dados de ${key}:`, e);
        return defaultValue;
    }
}

function saveToStorage(baseKey, data) {
    const key = `${baseKey}_${currentUserEmail}`;
    localStorage.setItem(key, JSON.stringify(data));
}

function fileToBase64(file) {
    if (file.size > 1024 * 1024 * 1) {
        alert("A imagem é muito grande. Por favor, selecione uma menor (máx. 1MB).");
        return Promise.reject(new Error("File too large"));
    }
    
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
        reader.readAsDataURL(file);
    });
}


// =================================================================
//          2. AUTENTICAÇÃO E SESSÃO
// =================================================================

function checkAuthentication() {
    currentUserEmail = localStorage.getItem(BASE_KEYS.CURRENT_USER_EMAIL_KEY);

    if (!currentUserEmail) {
        window.location.href = 'index.html';
        return false;
    }
    
    return true;
}


// =================================================================
//          3. GERENCIAMENTO DE PERFIL 📸
// =================================================================

function loadProfile() {
    const profile = loadFromStorage(BASE_KEYS.PROFILE, {
        name: 'Usuário',
        email: currentUserEmail || 'usuario@email.com',
        photo: 'https://via.placeholder.com/40'
    });

    currentProfilePhotoBase64 = profile.photo;

    // Acessa elementos apenas se existirem
    if (elements.headerName) elements.headerName.textContent = profile.name;
    if (elements.headerProfileImg) elements.headerProfileImg.src = profile.photo;
    if (elements.profileImg) elements.profileImg.src = profile.photo;
    if (elements.profileNameInput) elements.profileNameInput.value = profile.name;
    if (elements.profileEmailInput) elements.profileEmailInput.value = profile.email; 
}

function saveProfile(event) {
    event.preventDefault();

    const newProfile = {
        name: elements.profileNameInput.value.trim() || 'Usuário',
        email: currentUserEmail,
        photo: currentProfilePhotoBase64
    };

    saveToStorage(BASE_KEYS.PROFILE, newProfile);
    loadProfile();
    toggleModal(false);
}

async function handleProfilePhotoChange(event) {
    const file = event.target.files[0];
    if (file) {
        try {
            const base64String = await fileToBase64(file);
            currentProfilePhotoBase64 = base64String;
            if (elements.profileImg) elements.profileImg.src = base64String;
        } catch (error) {
            console.error('Erro ao converter foto para Base64:', error);
            if (elements.profilePhotoInput) elements.profilePhotoInput.value = '';
        }
    }
}

function toggleModal(show) {
    if (elements.profileModal) elements.profileModal.classList.toggle('hidden', !show);
}

function setupProfileEventListeners() {
    if (elements.profileBtn) elements.profileBtn.addEventListener('click', () => toggleModal(true));
    document.querySelectorAll('#nav-perfil').forEach(btn => {
        btn.addEventListener('click', () => toggleModal(true));
    });
    if (elements.closeModalBtn) elements.closeModalBtn.addEventListener('click', () => toggleModal(false));
    if (elements.profileForm) elements.profileForm.addEventListener('submit', saveProfile);
    if (elements.editPhotoBtn && elements.profilePhotoInput) {
         elements.editPhotoBtn.addEventListener('click', () => elements.profilePhotoInput.click());
    }
    if (elements.profilePhotoInput) elements.profilePhotoInput.addEventListener('change', handleProfilePhotoChange);
    if (elements.logoutBtn) {
        elements.logoutBtn.addEventListener('click', () => {
            localStorage.removeItem(BASE_KEYS.CURRENT_USER_EMAIL_KEY);
            window.location.href = 'index.html';
        });
    }
}


// =================================================================
//          4. GERENCIAMENTO DE ATIVIDADES (POSTS) 📝
// =================================================================

function createPostHTML(post) {
    const categoryUpper = post.category.toUpperCase();
    const categoryClass = post.category === 'esporte' ? 'bg-green-100 text-green-800' :
                          post.category === 'leitura' ? 'bg-blue-100 text-blue-800' :
                          post.category === 'natureza' ? 'bg-lime-100 text-lime-800' :
                          post.category === 'arte' ? 'bg-purple-100 text-purple-800' :
                          post.category === 'social' ? 'bg-yellow-100 text-yellow-800' :
                          post.category === 'meditacao' ? 'bg-indigo-100 text-indigo-800' :
                          'bg-gray-100 text-gray-800';
    
    const checkBtnClass = post.completed ? 'text-white bg-primary hover:bg-green-600' : 'text-primary bg-white hover:bg-green-100 border border-primary';

    const formattedDate = new Date(post.timestamp).toLocaleDateString('pt-BR', {
        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    return `
        <div class="post-item bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div class="flex justify-between items-start mb-3">
                <span class="text-xs font-semibold px-2.5 py-0.5 rounded-full ${categoryClass}">
                    ${categoryUpper}
                </span>
                
                <div class="flex gap-2">
                    <button 
                        class="toggle-complete-btn w-6 h-6 rounded-full flex items-center justify-center transition-all-smooth ${checkBtnClass}"
                        data-id="${post.id}"
                        title="${post.completed ? 'Desmarcar Meta' : 'Marcar como Meta Cumprida'}"
                    >
                        <i class="bi bi-check text-base"></i>
                    </button>
                    
                    <button 
                        class="delete-post-btn text-red-500 hover:text-red-700 transition-all-smooth text-lg"
                        data-id="${post.id}"
                        title="Excluir Atividade"
                    >
                        &times;
                    </button>
                </div>
            </div>
            ${post.image ? `<img src="${post.image}" alt="Atividade" class="w-full h-48 object-cover rounded-lg mb-3" />` : ''}
            <p class="text-sm text-secondary-foreground mb-1">${post.text}</p>
            <p class="text-xs text-secondary mt-2">Publicado em: ${formattedDate}</p>
        </div>
    `;
}

function renderPosts() {
    if (!elements.postsContainer) {
        console.warn("postsContainer não encontrado. O feed não pode ser renderizado.");
        return; 
    }

    currentPosts = loadFromStorage(BASE_KEYS.POSTS, []);
    elements.postsContainer.innerHTML = '';
    
    const totalCount = currentPosts.length;

    if (totalCount === 0) {
        if (elements.emptyPosts) elements.emptyPosts.classList.remove('hidden');
        updateHomeStats(); 
        updatePraiseMessage(0);
        return;
    }

    if (elements.emptyPosts) elements.emptyPosts.classList.add('hidden');
    
    const reversedPosts = [...currentPosts].reverse();
    
    reversedPosts.forEach((post) => {
        elements.postsContainer.innerHTML += createPostHTML(post);
    });

    document.querySelectorAll('.delete-post-btn').forEach(button => {
        button.addEventListener('click', deletePost);
    });
    document.querySelectorAll('.toggle-complete-btn').forEach(button => {
        button.addEventListener('click', toggleComplete);
    });

    updateHomeStats(); 
    updatePraiseMessage(totalCount);
}

function addPost(event) {
    event.preventDefault();
    
    const category = document.getElementById('post-category').value;
    const text = document.getElementById('post-text').value.trim();

    if (!category || !text) {
        alert('Por favor, selecione uma categoria e descreva sua atividade.');
        return;
    }

    const newPost = {
        id: Date.now(),
        category: category,
        text: text,
        image: currentPostImageBase64 || null,
        timestamp: new Date().toISOString(),
        completed: false
    };

    currentPosts.push(newPost);
    saveToStorage(BASE_KEYS.POSTS, currentPosts);
    renderPosts();

    if (elements.postForm) elements.postForm.reset();
    removePostImage();
}

function deletePost(event) {
    const postId = parseInt(event.currentTarget.dataset.id);
    
    if (confirm('Tem certeza que deseja excluir esta atividade?')) {
        currentPosts = currentPosts.filter(post => post.id !== postId);
        
        saveToStorage(BASE_KEYS.POSTS, currentPosts);
        renderPosts();
    }
}

function toggleComplete(event) {
    const postId = parseInt(event.currentTarget.dataset.id);
    
    const postIndex = currentPosts.findIndex(post => post.id === postId);

    if (postIndex !== -1) {
        currentPosts[postIndex].completed = !currentPosts[postIndex].completed;
        
        saveToStorage(BASE_KEYS.POSTS, currentPosts);
        renderPosts();
    }
}

async function handlePostImageChange(event) {
    const file = event.target.files[0];
    if (file) {
        try {
            const base64String = await fileToBase64(file);
            currentPostImageBase64 = base64String;
            if (elements.previewImg) elements.previewImg.src = base64String;
            if (elements.imagePreview) elements.imagePreview.classList.remove('hidden');
            if (elements.uploadBtn) elements.uploadBtn.textContent = `Foto selecionada: ${file.name}`;
        } catch (error) {
            if (elements.postImageInput) elements.postImageInput.value = '';
        }
    }
}

function removePostImage() {
    currentPostImageBase64 = '';
    if (elements.postImageInput) elements.postImageInput.value = '';
    if (elements.imagePreview) elements.imagePreview.classList.add('hidden');
    if (elements.previewImg) elements.previewImg.src = '';
    if (elements.uploadBtn) elements.uploadBtn.textContent = 'Clique para adicionar foto';
}

function setupPostEventListeners() {
    if (elements.postForm) elements.postForm.addEventListener('submit', addPost);
    if (elements.uploadBtn) elements.uploadBtn.addEventListener('click', () => elements.postImageInput.click());
    if (elements.postImageInput) elements.postImageInput.addEventListener('change', handlePostImageChange);
    if (elements.removeImageBtn) elements.removeImageBtn.addEventListener('click', removePostImage);
}


// =================================================================
//          5. GERENCIAMENTO DE METAS 🎯
// =================================================================

function loadMetas() {
    const metas = loadFromStorage(BASE_KEYS.METAS, {
        offlineHours: CHART_CONFIG.DEFAULT_OFFLINE_GOAL,
        freeTimes: ''
    });

    if (elements.horasOfflineInput) elements.horasOfflineInput.value = metas.offlineHours;
    if (elements.horariosLivresInput) elements.horariosLivresInput.value = metas.freeTimes;
    
    return metas;
}

function saveMetas(event) {
    event.preventDefault();
    
    const offlineHours = parseInt(elements.horasOfflineInput.value);
    const freeTimes = elements.horariosLivresInput.value.trim();

    if (isNaN(offlineHours) || offlineHours < 0 || offlineHours > 24) {
        alert('Por favor, insira um valor válido para as horas offline (0 a 24).');
        return;
    }

    const newMetas = {
        offlineHours: offlineHours,
        freeTimes: freeTimes
    };

    saveToStorage(BASE_KEYS.METAS, newMetas);
    alert('Metas salvas com sucesso!');
}

function setupMetasEventListeners() {
    if (elements.metasForm) elements.metasForm.addEventListener('submit', saveMetas);
}


// =================================================================
//          6. GERENCIAMENTO DE GRÁFICO E ELOGIOS 📊
// =================================================================

function updatePraiseMessage(activityCount) {
    if (!elements.praiseMessage) return;

    let message = '';
    let bgColor = 'bg-gray-100';
    let textColor = 'text-gray-800';

    if (activityCount === 0) {
        message = 'Olá! Seu progresso ainda não foi medido. Publique sua primeira atividade!';
        bgColor = 'bg-yellow-100';
        textColor = 'text-yellow-800';
    } else if (activityCount <= 3) {
        message = 'Ótimo começo! Você já registrou suas primeiras atividades. Continue assim!';
        bgColor = 'bg-blue-100';
        textColor = 'text-blue-800';
    } else if (activityCount <= 10) {
        message = 'Fabuloso! Sua dedicação é inspiradora. Você está construindo uma rotina de desconexão sólida.';
        bgColor = 'bg-green-100';
        textColor = 'text-green-800';
    } else {
        message = 'Incrível! Você é um mestre da desconexão! Seu histórico mostra um compromisso exemplar.';
        bgColor = 'bg-primary'; 
        textColor = 'text-white';
    }

    elements.praiseMessage.className = `p-4 mb-6 rounded-lg border font-semibold ${bgColor} ${textColor}`;
    elements.praiseMessage.textContent = message;
}

function updateHomeStats() { 
    const completedCount = currentPosts.filter(post => post.completed).length;
    const totalCount = currentPosts.length;
    
    if (elements.completedCountHome) {
        elements.completedCountHome.textContent = completedCount;
    }
    if (elements.totalCountHome) {
        elements.totalCountHome.textContent = totalCount;
    }
}


// =================================================================
//          7. LÓGICA DE NAVEGAÇÃO ENTRE PÁGINAS ✨
// =================================================================

function showPage(pageId) {
    // 1. Esconde TODAS as páginas
    if (elements.allPages) {
        elements.allPages.forEach(page => {
            page.classList.add('hidden-page');
            page.style.display = 'none'; // Adiciona display: none como fallback
        });
    }

    // 2. Tenta mostrar a página alvo
    const targetPageElement = document.getElementById(`${pageId}-page`);
    if (targetPageElement) {
        // Remove a classe de ocultação e o fallback de estilo
        targetPageElement.classList.remove('hidden-page');
        targetPageElement.style.display = ''; // Volta ao display padrão (block/flex)
    }

    // 3. Destaca o link ativo na sidebar
    if (elements.sidebarLinks) {
        elements.sidebarLinks.forEach(link => {
            if (link.dataset.page === pageId) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    // 4. Executa ações específicas da página
    if (pageId === 'metas') {
        loadMetas();
    }
    
    // CRÍTICO: Se for a página de rotina, garante que os posts sejam renderizados
    if (pageId === 'rotina') {
        renderPosts();
    }
    
    const mainContent = document.querySelector('.main-content');
    if (mainContent) mainContent.scrollTop = 0;
}


function closeSidebar() {
    if (elements.sidebar) elements.sidebar.classList.remove('open');
    if (elements.sidebarOverlay) {
        elements.sidebarOverlay.classList.add('hidden');
        elements.sidebarOverlay.classList.remove('opacity-100');
        elements.sidebarOverlay.classList.add('opacity-0');
    }
}

function openSidebar() {
    if (elements.sidebar) elements.sidebar.classList.add('open');
    if (elements.sidebarOverlay) {
        elements.sidebarOverlay.classList.remove('hidden');
        setTimeout(() => { 
            elements.sidebarOverlay.classList.remove('opacity-0');
            elements.sidebarOverlay.classList.add('opacity-100');
        }, 10);
    }
}

function handleSidebarNavigation(event) {
    event.preventDefault();
    const link = event.currentTarget;
    const targetPage = link.dataset.page;
    
    if (targetPage === 'perfil') {
        toggleModal(true); 
    } else {
        showPage(targetPage);
    }

    if (window.innerWidth < 768) { 
        closeSidebar();
    }
}

function setupNavigationEventListeners() {
    if (elements.menuToggleBtn) elements.menuToggleBtn.addEventListener('click', openSidebar);
    if (elements.closeSidebarBtn) elements.closeSidebarBtn.addEventListener('click', closeSidebar);
    if (elements.sidebarOverlay) elements.sidebarOverlay.addEventListener('click', closeSidebar); 
    if (elements.sidebarLinks) {
        elements.sidebarLinks.forEach(link => {
            link.addEventListener('click', handleSidebarNavigation);
        });
    }
    
    // Lógica de envio de sugestão (Mockup)
    if (document.getElementById('user-suggestion-form')) {
        document.getElementById('user-suggestion-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const suggestionText = document.getElementById('suggestion-text').value.trim();
            if (suggestionText) {
                alert(`Sua sugestão foi enviada para a comunidade: "${suggestionText}"`);
                document.getElementById('user-suggestion-form').reset();
            }
        });
    }
}


// =================================================================
//          8. INICIALIZAÇÃO PRINCIPAL 🚀
// =================================================================

function initDashboard() {
    // 1. Cria o objeto 'elements' após o DOM estar pronto
    elements = {
        sidebar: document.getElementById('sidebar'),
        menuToggleBtn: document.getElementById('menu-toggle-btn'),
        closeSidebarBtn: document.getElementById('close-sidebar-btn'),
        sidebarOverlay: document.getElementById('sidebar-overlay'),
        sidebarLinks: document.querySelectorAll('#sidebar .sidebar-link'),
        allPages: document.querySelectorAll('.main-content section'),
        
        // Home
        praiseMessage: document.getElementById('praise-message'),
        completedCountHome: document.getElementById('completed-count-home'), 
        totalCountHome: document.getElementById('total-count-home'),

        // Perfil
        profileModal: document.getElementById('profile-modal'),
        closeModalBtn: document.getElementById('close-modal'),
        profileBtn: document.getElementById('profile-btn'),
        logoutBtn: document.getElementById('logout-btn'),
        profileForm: document.getElementById('profile-form'),
        profileImg: document.getElementById('profile-img'),
        profilePhotoInput: document.getElementById('profile-photo-input'),
        editPhotoBtn: document.getElementById('edit-photo-btn'),
        profileNameInput: document.getElementById('profile-name-input'),
        profileEmailInput: document.getElementById('profile-email'),
        headerProfileImg: document.getElementById('header-profile-img'),
        headerName: document.getElementById('header-name'),

        // Rotina (Posts)
        postForm: document.getElementById('post-form'),
        postImageInput: document.getElementById('post-image'),
        uploadBtn: document.getElementById('upload-btn'),
        imagePreview: document.getElementById('image-preview'),
        previewImg: document.querySelector('#image-preview img'),
        removeImageBtn: document.getElementById('remove-image'),
        postsContainer: document.getElementById('posts-container'),
        emptyPosts: document.getElementById('empty-posts'),

        // Metas
        metasForm: document.getElementById('metas-form'),
        horasOfflineInput: document.getElementById('horas-offline-input'),
        horariosLivresInput: document.getElementById('horarios-livres-input'),
    };
    
    // 2. Verifica a autenticação antes de prosseguir
    if (checkAuthentication()) {
        
        // 3. Configura todos os Listeners de Eventos
        setupProfileEventListeners();
        setupPostEventListeners();
        setupMetasEventListeners();
        setupNavigationEventListeners();
        
        // 4. Carrega os dados
        loadProfile();
        loadMetas(); 
        
        // 5. Renderiza dados e mostra a página inicial
        renderPosts(); // Garante que as estatísticas da Home fiquem corretas
        showPage('home'); 
    }
}

// INICIA O SCRIPT SOMENTE QUANDO A PÁGINA ESTIVER TOTALMENTE CARREGADA
document.addEventListener('DOMContentLoaded', initDashboard);